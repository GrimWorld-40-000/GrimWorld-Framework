﻿using GW4KArmor.Data;
using Verse;

namespace GW4KArmor;

public class DefaultPaletteExtension : DefModExtension
{
    public Palette defaultPalette;
}